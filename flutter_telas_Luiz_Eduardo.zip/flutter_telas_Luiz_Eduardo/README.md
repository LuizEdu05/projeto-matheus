QuickOrder - Mock Flutter UI for academic assignment
---------------------------------------------------

Conteúdo:
- Projeto Flutter minimal contendo 10 telas independentes (Splash, Login, Cadastro, Lista de Restaurantes,
Detalhes do Restaurante, Produto, Carrinho, Checkout, Avaliação, Perfil).

Como usar:
1. Renomeie a pasta/arquivo ZIP para seguir o padrão exigido: flutter_telas_seuNome_sobrenome.zip
2. Abra o projeto com Flutter (Flutter SDK instalado).
3. Execute `flutter pub get` e `flutter run` em um emulador ou dispositivo.
4. As telas podem ser navegadas a partir da Splash inicial ou diretamente por rotas:
   '/', '/login', '/signup', '/restaurants', '/restaurant_details', '/product', '/cart', '/checkout', '/rating', '/profile'

Observações:
- O projeto é uma simulação visual. Não há backend e os dados são estáticos.
- O código está organizado em /lib/screens para facilitar análise e edição.
- Se quiser que eu personalize cores, tipografia ou adicione mais componentes reutilizáveis, me diga e eu atualizo.
