import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/restaurants_list_screen.dart';
import 'screens/restaurant_details_screen.dart';
import 'screens/product_screen.dart';
import 'screens/cart_screen.dart';
import 'screens/checkout_screen.dart';
import 'screens/rating_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  runApp(QuickOrderApp());
}

class QuickOrderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QuickOrder (Mock)',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0xFFF6F8FA),
      ),
      initialRoute: '/',
      routes: {
        '/': (_) => SplashScreen(),
        '/login': (_) => LoginScreen(),
        '/signup': (_) => SignupScreen(),
        '/restaurants': (_) => RestaurantsListScreen(),
        '/restaurant_details': (_) => RestaurantDetailsScreen(),
        '/product': (_) => ProductScreen(),
        '/cart': (_) => CartScreen(),
        '/checkout': (_) => CheckoutScreen(),
        '/rating': (_) => RatingScreen(),
        '/profile': (_) => ProfileScreen(),
      },
    );
  }
}
