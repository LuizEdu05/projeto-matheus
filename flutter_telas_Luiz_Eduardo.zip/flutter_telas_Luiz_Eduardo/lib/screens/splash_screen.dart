import 'package:flutter/material.dart';

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Simple splash/welcome screen with CTA to Login
    return Scaffold(
      body: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 28),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0F172A), Color(0xFF0B84FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.fastfood, size: 96, color: Colors.white),
            SizedBox(height: 24),
            Text('QuickOrder',
              style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w700)
            ),
            SizedBox(height: 12),
            Text('Peça sua refeição favorita com rapidez e praticidade.',
              style: TextStyle(color: Colors.white70, fontSize: 16), textAlign: TextAlign.center),
            SizedBox(height: 36),
            ElevatedButton(
              onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                child: Text('Começar', style: TextStyle(fontSize: 16)),
              ),
              style: ElevatedButton.styleFrom(
                shape: StadiumBorder(),
                backgroundColor: Colors.white,
                foregroundColor: Color(0xFF0B84FF),
              ),
            ),
            SizedBox(height: 12),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, '/restaurants'),
              child: Text('Explorar sem login', style: TextStyle(color: Colors.white70)),
            )
          ],
        ),
      ),
    );
  }
}
