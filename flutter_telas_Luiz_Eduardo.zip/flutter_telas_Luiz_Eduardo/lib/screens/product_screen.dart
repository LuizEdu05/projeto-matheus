import 'package:flutter/material.dart';

class ProductScreen extends StatefulWidget {
  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  int qty = 1;
  String obs = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Produto'), backgroundColor: Colors.transparent, foregroundColor: Colors.black87, elevation: 0),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(height:180, decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Colors.grey[100]),
              child: Center(child: Icon(Icons.restaurant_menu, size:72, color: Colors.blueAccent))),
            SizedBox(height:12),
            Text('Prato Exemplo', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)),
            SizedBox(height:6),
            Text('Descrição breve do prato. Ingredientes e observações.', style: TextStyle(color: Colors.black54)),
            SizedBox(height:12),
            Row(children: [
              Text('Quantidade', style: TextStyle(fontWeight: FontWeight.w600)),
              Spacer(),
              IconButton(onPressed: ()=>setState(()=>qty = (qty-1).clamp(1,99)), icon: Icon(Icons.remove_circle_outline)),
              Text('\$qty', style: TextStyle(fontWeight: FontWeight.bold)),
              IconButton(onPressed: ()=>setState(()=>qty = (qty+1).clamp(1,99)), icon: Icon(Icons.add_circle_outline)),
            ]),
            SizedBox(height:10),
            TextField(
              decoration: InputDecoration(labelText: 'Observações (opcional)'),
              onChanged: (v)=>obs = v,
            ),
            Spacer(),
            Row(children: [
              Expanded(child: OutlinedButton(onPressed: ()=>Navigator.pop(context), child: Text('Voltar'))),
              SizedBox(width:10),
              Expanded(child: ElevatedButton(onPressed: (){
                // Simula adicionar ao carrinho
                Navigator.pushNamed(context, '/cart');
              }, child: Text('Adicionar ao carrinho'))),
            ])
          ],
        ),
      ),
    );
  }
}
