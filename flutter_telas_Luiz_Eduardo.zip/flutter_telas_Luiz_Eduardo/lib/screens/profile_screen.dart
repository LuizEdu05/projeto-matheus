import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Perfil'), backgroundColor: Colors.transparent, foregroundColor: Colors.black87, elevation: 0),
      body: Padding(
        padding: EdgeInsets.all(18),
        child: Column(
          children: [
            Row(children: [
              CircleAvatar(radius:36, child: Icon(Icons.person, size:36)),
              SizedBox(width:12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Usuário Exemplo', style: TextStyle(fontWeight: FontWeight.bold, fontSize:18)),
                SizedBox(height:4),
                Text('user@example.com', style: TextStyle(color: Colors.black54))
              ])
            ]),
            SizedBox(height:18),
            Card(child: ListTile(leading: Icon(Icons.history), title: Text('Pedidos anteriores'), trailing: Icon(Icons.chevron_right))),
            Card(child: ListTile(leading: Icon(Icons.payment), title: Text('Formas de pagamento'), trailing: Icon(Icons.chevron_right))),
            Card(child: ListTile(leading: Icon(Icons.logout), title: Text('Sair'), trailing: Icon(Icons.chevron_right))),
          ],
        ),
      ),
    );
  }
}
