import 'package:flutter/material.dart';

class CartScreen extends StatelessWidget {
  final List<Map<String,dynamic>> items = [
    {'title':'Prato Exemplo 1','qty':2,'price':25.0},
    {'title':'Acompanhamento','qty':1,'price':8.0}
  ];

  double get subtotal => items.fold(0, (s, e) => s + e['qty'] * e['price']);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Carrinho'), backgroundColor: Colors.transparent, foregroundColor: Colors.black87, elevation: 0),
      body: Padding(
        padding: EdgeInsets.all(14),
        child: Column(
          children: [
            Expanded(
              child: ListView.separated(
                itemCount: items.length,
                separatorBuilder: (_,__)=>SizedBox(height:8),
                itemBuilder: (context, i){
                  final it = items[i];
                  return Card(
                    child: ListTile(
                      title: Text(it['title']),
                      subtitle: Text('Quantidade: \${it['qty']}'),
                      trailing: Text('R\$ \${(it['price']*it['qty']).toStringAsFixed(2)}'),
                    ),
                  );
                },
              ),
            ),
            Divider(),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children:[
              Text('Subtotal', style: TextStyle(fontWeight: FontWeight.w600)),
              Text('R\$ \${subtotal.toStringAsFixed(2)}')
            ]),
            SizedBox(height:10),
            ElevatedButton(onPressed: ()=>Navigator.pushNamed(context, '/checkout'), child: SizedBox(width: double.infinity, child: Center(child: Text('Finalizar pedido')))),
          ],
        ),
      ),
    );
  }
}
