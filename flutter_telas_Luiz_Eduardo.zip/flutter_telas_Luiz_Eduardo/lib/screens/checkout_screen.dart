import 'package:flutter/material.dart';

class CheckoutScreen extends StatefulWidget {
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String payment = 'card';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Checkout'), backgroundColor: Colors.transparent, foregroundColor: Colors.black87, elevation: 0),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            ListTile(leading: Icon(Icons.location_on), title: Text('Endereço de entrega'), subtitle: Text('Rua Exemplo, 123')),
            SizedBox(height:10),
            Align(alignment: Alignment.centerLeft, child: Text('Forma de pagamento', style: TextStyle(fontWeight: FontWeight.w600))),
            SizedBox(height:8),
            RadioListTile(value: 'card', groupValue: payment, onChanged: (v)=>setState(()=>payment=v.toString()), title: Text('Cartão de crédito')),
            RadioListTile(value: 'cash', groupValue: payment, onChanged: (v)=>setState(()=>payment=v.toString()), title: Text('Dinheiro (na entrega)')),
            Spacer(),
            ElevatedButton(onPressed: (){
              // Simula conclusão
              Navigator.pushNamed(context, '/rating');
            }, child: SizedBox(width: double.infinity, child: Center(child: Text('Pagar e finalizar'))))
          ],
        ),
      ),
    );
  }
}
