import 'package:flutter/material.dart';

class RestaurantDetailsScreen extends StatelessWidget {
  final List<Map<String,String>> menu = List.generate(6, (i) => {
    'title': 'Prato Especial ${(i+1)}',
    'desc': 'Descrição deliciosa que chama atenção.',
    'price': 'R\$ ${(20 + i*5).toStringAsFixed(2)}'
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalhes do Restaurante'),
        backgroundColor: Colors.transparent, foregroundColor: Colors.black87, elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height:160, width: double.infinity,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Colors.blueGrey[50]),
              child: Center(child: Icon(Icons.storefront, size:64, color: Colors.blueAccent)),
            ),
            SizedBox(height:12),
            Text('Restaurante Exemplo', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)),
            SizedBox(height:6),
            Text('Culinária Brasileira • Aberto • Retirada e Entrega', style: TextStyle(color: Colors.black54)),
            SizedBox(height:12),
            Text('Cardápio', style: TextStyle(fontSize:18, fontWeight: FontWeight.w600)),
            SizedBox(height:8),
            Column(children: menu.map((item){
              return Card(
                elevation: 1,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: ListTile(
                  title: Text(item['title']!),
                  subtitle: Text(item['desc']!),
                  trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(item['price']!, style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height:6),
                    ElevatedButton(onPressed: ()=>Navigator.pushNamed(context, '/product'), child: Text('Ver')),
                  ]),
                ),
              );
            }).toList())
          ],
        ),
      ),
    );
  }
}
