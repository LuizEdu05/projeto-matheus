import 'package:flutter/material.dart';

class RatingScreen extends StatefulWidget {
  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  double rating = 4.0;
  String comment = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Avaliação do pedido'), backgroundColor: Colors.transparent, foregroundColor: Colors.black87, elevation: 0),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Como foi sua experiência?', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)),
            SizedBox(height:12),
            Slider(value: rating, min:1, max:5, divisions:4, label: rating.toString(), onChanged: (v)=>setState(()=>rating=v)),
            SizedBox(height:8),
            TextField(decoration: InputDecoration(labelText: 'Comentário (opcional)'), onChanged: (v)=>comment=v),
            Spacer(),
            ElevatedButton(onPressed: ()=>Navigator.pushNamedAndRemoveUntil(context, '/restaurants', (r)=>false), child: SizedBox(width: double.infinity, child: Center(child: Text('Enviar avaliação'))))
          ],
        ),
      ),
    );
  }
}
