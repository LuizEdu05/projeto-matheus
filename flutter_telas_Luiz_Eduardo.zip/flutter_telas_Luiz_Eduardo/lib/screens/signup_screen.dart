import 'package:flutter/material.dart';

class SignupScreen extends StatefulWidget {
  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  String name='', email='', phone='';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Cadastro'), backgroundColor: Colors.transparent, foregroundColor: Colors.black87, elevation: 0),
      body: Padding(
        padding: EdgeInsets.all(18),
        child: Column(
          children: [
            Text('Crie sua conta', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Form(
              key: _formKey,
              child: Column(children: [
                TextFormField(decoration: InputDecoration(labelText: 'Nome completo', prefixIcon: Icon(Icons.person)),
                  validator: (v){ if (v==null||v.isEmpty) return 'Digite seu nome'; return null;},
                  onSaved: (v)=>name=v??'',
                ),
                SizedBox(height: 12),
                TextFormField(decoration: InputDecoration(labelText: 'E-mail', prefixIcon: Icon(Icons.email)),
                  keyboardType: TextInputType.emailAddress,
                  validator: (v){ if (v==null||!v.contains('@')) return 'E-mail inválido'; return null;},
                  onSaved: (v)=>email=v??'',
                ),
                SizedBox(height: 12),
                TextFormField(decoration: InputDecoration(labelText: 'Telefone', prefixIcon: Icon(Icons.phone)),
                  keyboardType: TextInputType.phone,
                  onSaved: (v)=>phone=v??'',
                ),
                SizedBox(height: 18),
                ElevatedButton(onPressed: (){
                  if(_formKey.currentState!.validate()){
                    _formKey.currentState!.save();
                    Navigator.pushReplacementNamed(context, '/restaurants');
                  }
                }, child: SizedBox(width: double.infinity, child: Center(child: Text('Criar conta'))), style: ElevatedButton.styleFrom(shape: StadiumBorder()))
              ],),
            )
          ],
        ),
      ),
    );
  }
}
