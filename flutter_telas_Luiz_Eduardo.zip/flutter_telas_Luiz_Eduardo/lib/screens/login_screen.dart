import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  String email = '';
  String password = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black87,
      ),
      body: Padding(
        padding: EdgeInsets.all(18),
        child: Column(
          children: [
            SizedBox(height: 18),
            Text('Bem-vindo de volta', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Acesse sua conta para continuar com seus pedidos.', style: TextStyle(color: Colors.black54)),
            SizedBox(height: 18),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    decoration: InputDecoration(labelText: 'E-mail', prefixIcon: Icon(Icons.email)),
                    keyboardType: TextInputType.emailAddress,
                    validator: (v) {
                      if (v==null || v.isEmpty) return 'Digite seu e-mail';
                      if (!v.contains('@')) return 'E-mail inválido';
                      return null;
                    },
                    onSaved: (v) => email = v ?? '',
                  ),
                  SizedBox(height: 12),
                  TextFormField(
                    decoration: InputDecoration(labelText: 'Senha', prefixIcon: Icon(Icons.lock)),
                    obscureText: true,
                    validator: (v) {
                      if (v==null || v.length < 6) return 'Senha com no mínimo 6 caracteres';
                      return null;
                    },
                    onSaved: (v) => password = v ?? '',
                  ),
                  SizedBox(height: 18),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        // Simula login
                        Navigator.pushReplacementNamed(context, '/restaurants');
                      }
                    },
                    child: SizedBox(
                      width: double.infinity,
                      child: Center(child: Text('Entrar')),
                    ),
                    style: ElevatedButton.styleFrom(shape: StadiumBorder()),
                  ),
                ],
              ),
            ),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Ainda não tem conta?'),
                TextButton(onPressed: () => Navigator.pushNamed(context, '/signup'), child: Text('Cadastre-se'))
              ],
            )
          ],
        ),
      ),
    );
  }
}
