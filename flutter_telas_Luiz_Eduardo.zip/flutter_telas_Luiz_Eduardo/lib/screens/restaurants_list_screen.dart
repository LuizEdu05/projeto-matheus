import 'package:flutter/material.dart';

class RestaurantsListScreen extends StatelessWidget {
  final List<Map<String,String>> items = List.generate(8, (i) => {
    'name': 'Restaurante ${(i+1)}',
    'subtitle': 'Culinária Variada • ${(10+i)}-30 min',
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Restaurantes'),
        actions: [
          IconButton(onPressed: ()=>Navigator.pushNamed(context,'/cart'), icon: Icon(Icons.shopping_cart))
        ],
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: ListView.separated(
          itemCount: items.length,
          separatorBuilder: (_,__)=>SizedBox(height:10),
          itemBuilder: (context, idx){
            final r = items[idx];
            return InkWell(
              onTap: ()=>Navigator.pushNamed(context, '/restaurant_details'),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(12),
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0,2))]
                ),
                padding: EdgeInsets.all(12),
                child: Row(
                  children: [
                    Container(width:72, height:72, decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.blueGrey[50]),
                      child: Icon(Icons.restaurant, size:36, color: Colors.blueAccent),),
                    SizedBox(width:12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
                      Text(r['name']!, style: TextStyle(fontWeight: FontWeight.w600)),
                      SizedBox(height:4),
                      Text(r['subtitle']!, style: TextStyle(color: Colors.black54)),
                      SizedBox(height:8),
                      Row(children:[
                        Icon(Icons.star, size:14, color:Colors.amber),
                        SizedBox(width:6),
                        Text('4.${idx%5} • ${15+idx} - ${30+idx} min', style: TextStyle(color: Colors.black45, fontSize:12))
                      ])
                    ]))
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
