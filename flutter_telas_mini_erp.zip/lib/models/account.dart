enum AccountType { payable, receivable }

class Account {
  final String id;
  final String title;
  final double amount;
  final DateTime dueDate;
  bool received;
  final AccountType type;
  Account({required this.id, required this.title, required this.amount, required this.dueDate, required this.received, required this.type});
}