import 'sale_item.dart';

class Sale {
  final String id;
  final String customerId;
  final DateTime date;
  final List<SaleItem> items;
  final double total;
  Sale({required this.id, required this.customerId, required this.date, required this.items, required this.total});
}