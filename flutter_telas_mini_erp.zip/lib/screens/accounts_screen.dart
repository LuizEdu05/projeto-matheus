import 'package:flutter/material.dart';
import '../data/data_repository.dart';
import '../models/account.dart';

class AccountsScreen extends StatefulWidget {
  const AccountsScreen({super.key});
  @override
  State<AccountsScreen> createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen> {
  final repo = DataRepository.instance;
  @override
  Widget build(BuildContext context) {
    final payables = repo.accounts.where((a)=> a.type == AccountType.payable).toList();
    final receivables = repo.accounts.where((a)=> a.type == AccountType.receivable).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Contas a Pagar / Receber')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(children: [
          const Text('A Receber', style: TextStyle(fontWeight: FontWeight.bold)),
          Expanded(
            child: ListView.builder(
              itemCount: receivables.length,
              itemBuilder: (c, i) {
                final a = receivables[i];
                return Card(
                  child: ListTile(
                    title: Text(a.title),
                    subtitle: Text('Vencimento: \${a.dueDate.day}/\${a.dueDate.month}/\${a.dueDate.year}'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('R\$ \${a.amount.toStringAsFixed(2)}'),
                      IconButton(icon: Icon(a.received ? Icons.check_box : Icons.check_box_outline_blank), onPressed: (){ setState(()=> repo.toggleAccountPaid(a.id)); }),
                    ]),
                  ),
                );
              },
            ),
          ),
          const Divider(),
          const Text('A Pagar', style: TextStyle(fontWeight: FontWeight.bold)),
          Expanded(
            child: ListView.builder(
              itemCount: payables.length,
              itemBuilder: (c, i) {
                final a = payables[i];
                return Card(
                  child: ListTile(
                    title: Text(a.title),
                    subtitle: Text('Vencimento: \${a.dueDate.day}/\${a.dueDate.month}/\${a.dueDate.year}'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('R\$ \${a.amount.toStringAsFixed(2)}'),
                      IconButton(icon: Icon(a.received ? Icons.check_box : Icons.check_box_outline_blank), onPressed: (){ setState(()=> repo.toggleAccountPaid(a.id)); }),
                    ]),
                  ),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}