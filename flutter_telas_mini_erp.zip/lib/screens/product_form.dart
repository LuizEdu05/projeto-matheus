import 'package:flutter/material.dart';

import '../models/product.dart';
import '../data/data_repository.dart';

class ProductFormScreen extends StatefulWidget {
  const ProductFormScreen({super.key});
  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _form = GlobalKey<FormState>();
  final repo = DataRepository.instance;
  final nameCtrl = TextEditingController();
  final priceCtrl = TextEditingController();
  final stockCtrl = TextEditingController();

  void _save() {
    if (_form.currentState?.validate() ?? false) {
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final p = Product(id: id, name: nameCtrl.text.trim(), price: double.parse(priceCtrl.text), stock: int.parse(stockCtrl.text));
      repo.addProduct(p);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Produto salvo')));
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    nameCtrl.dispose();
    priceCtrl.dispose();
    stockCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro de Produto')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _form,
          child: Column(
            children: [
              TextFormField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Nome'), validator: (v)=> (v==null || v.isEmpty)?'Informe nome':null),
              const SizedBox(height: 12),
              TextFormField(controller: priceCtrl, decoration: const InputDecoration(labelText: 'Preço'), keyboardType: TextInputType.numberWithOptions(decimal: true), validator: (v)=> (v==null || v.isEmpty)?'Informe preço':null),
              const SizedBox(height: 12),
              TextFormField(controller: stockCtrl, decoration: const InputDecoration(labelText: 'Estoque'), keyboardType: TextInputType.number, validator: (v)=> (v==null || v.isEmpty)?'Informe estoque':null),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, height: 48, child: ElevatedButton(onPressed: _save, child: const Text('Salvar'))),
            ],
          ),
        ),
      ),
    );
  }
}