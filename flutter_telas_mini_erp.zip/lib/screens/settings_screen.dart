import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool dark = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(children: [
          SwitchListTile(title: const Text('Tema escuro'), value: dark, onChanged: (v)=> setState(()=> dark = v)),
          ListTile(title: const Text('Perfil da empresa'), subtitle: const Text('Nome da empresa, endereço...')),
        ]),
      ),
    );
  }
}