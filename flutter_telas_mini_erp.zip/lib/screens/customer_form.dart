import 'package:flutter/material.dart';

import '../models/customer.dart';
import '../data/data_repository.dart';

class CustomerFormScreen extends StatefulWidget {
  const CustomerFormScreen({super.key});
  @override
  State<CustomerFormScreen> createState() => _CustomerFormScreenState();
}

class _CustomerFormScreenState extends State<CustomerFormScreen> {
  final _form = GlobalKey<FormState>();
  final repo = DataRepository.instance;
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();

  void _save() {
    if (_form.currentState?.validate() ?? false) {
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final c = Customer(id: id, name: nameCtrl.text.trim(), phone: phoneCtrl.text.trim());
      repo.addCustomer(c);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cliente salvo')));
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    nameCtrl.dispose();
    phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro de Cliente')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _form,
          child: Column(
            children: [
              TextFormField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Nome'), validator: (v)=> (v==null || v.isEmpty)?'Informe nome':null),
              const SizedBox(height: 12),
              TextFormField(controller: phoneCtrl, decoration: const InputDecoration(labelText: 'Telefone'), validator: (v)=> (v==null || v.isEmpty)?'Informe telefone':null),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, height: 48, child: ElevatedButton(onPressed: _save, child: const Text('Salvar'))),
            ],
          ),
        ),
      ),
    );
  }
}