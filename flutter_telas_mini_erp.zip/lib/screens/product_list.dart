import 'package:flutter/material.dart';
import '../data/data_repository.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});
  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  final repo = DataRepository.instance;
  String query = '';

  @override
  Widget build(BuildContext context) {
    final items = repo.products.where((p) => p.name.toLowerCase().contains(query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Estoque'), actions: [
        IconButton(onPressed: () => Navigator.pushNamed(context, '/products/new').then((_) => setState(() {})), icon: const Icon(Icons.add))
      ]),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            TextField(decoration: const InputDecoration(labelText: 'Buscar produto'), onChanged: (v)=> setState(()=> query = v)),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (c, i) {
                  final p = items[i];
                  return Card(
                    child: ListTile(
                      title: Text(p.name),
                      subtitle: Text('R\$ \${p.price.toStringAsFixed(2)} • Estoque: \${p.stock}'),
                      trailing: p.stock <= 5 ? const Icon(Icons.warning, color: Colors.red) : null,
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}