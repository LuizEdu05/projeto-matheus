import 'package:flutter/material.dart';

import '../data/data_repository.dart';
import '../models/sale_item.dart';
import '../models/sale.dart';

class SaleScreen extends StatefulWidget {
  const SaleScreen({super.key});
  @override
  State<SaleScreen> createState() => _SaleScreenState();
}

class _SaleScreenState extends State<SaleScreen> {
  final repo = DataRepository.instance;
  String? selectedCustomer;
  final List<SaleItem> cart = [];
  String productQuery = '';
  int qty = 1;

  void _addItem(String id) {
    final p = repo.products.firstWhere((x) => x.id == id);
    setState(() {
      cart.add(SaleItem(productId: p.id, productName: p.name, quantity: qty, unitPrice: p.price));
    });
  }

  void _checkout() {
    if (selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Selecione um cliente')));
      return;
    }
    if (cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Adicione itens ao carrinho')));
      return;
    }
    final id = DateTime.now().microsecondsSinceEpoch.toString().substring(6);
    final total = cart.fold<double>(0, (p, e) => p + e.unitPrice * e.quantity);
    final sale = Sale(id: id, customerId: selectedCustomer!, date: DateTime.now(), items: cart.toList(), total: total);
    repo.addSale(sale);
    cart.clear();
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Venda registrada')));
  }

  @override
  Widget build(BuildContext context) {
    final products = repo.products.where((p) => p.name.toLowerCase().contains(productQuery.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Nova Venda')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: selectedCustomer,
              decoration: const InputDecoration(labelText: 'Cliente'),
              items: repo.customers.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
              onChanged: (v) => setState(()=> selectedCustomer = v),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: TextField(decoration: const InputDecoration(labelText: 'Buscar produto'), onChanged: (v)=> setState(()=> productQuery = v))),
              const SizedBox(width: 8),
              SizedBox(width: 100, child: TextField(decoration: const InputDecoration(labelText: 'Qtd'), keyboardType: TextInputType.number, onChanged: (v){ final n = int.tryParse(v); if(n!=null) qty = n; })),
            ]),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: products.length,
                itemBuilder: (c, i){
                  final p = products[i];
                  return Card(
                    child: ListTile(
                      title: Text(p.name),
                      subtitle: Text('R\$ \${p.price.toStringAsFixed(2)} • Estoque: \${p.stock}'),
                      trailing: IconButton(icon: const Icon(Icons.add_shopping_cart), onPressed: ()=> _addItem(p.id)),
                    ),
                  );
                },
              ),
            ),
            const Divider(),
            const Text('Carrinho', style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: cart.length,
                itemBuilder: (c, i){
                  final it = cart[i];
                  return ListTile(title: Text(it.productName), subtitle: Text('\${it.quantity} x R\$ \${it.unitPrice.toStringAsFixed(2)}'), trailing: Text('R\$ \${(it.unitPrice*it.quantity).toStringAsFixed(2)}'));
                },
              ),
            ),
            SizedBox(width: double.infinity, height: 48, child: ElevatedButton(onPressed: _checkout, child: const Text('Finalizar Venda'))),
          ],
        ),
      ),
    );
  }
}