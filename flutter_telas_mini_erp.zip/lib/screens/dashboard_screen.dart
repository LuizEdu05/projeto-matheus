import 'package:flutter/material.dart';
import '../data/data_repository.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final repo = DataRepository.instance;
  @override
  Widget build(BuildContext context) {
    final totalProducts = repo.products.length;
    final totalClients = repo.customers.length;
    final totalSales = repo.sales.fold<double>(0, (p, s) => p + s.total);
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(child: Text('Mini ERP')),
            ListTile(title: const Text('Produtos'), onTap: () => Navigator.pushNamed(context, '/products')),
            ListTile(title: const Text('Novo Produto'), onTap: () => Navigator.pushNamed(context, '/products/new')),
            ListTile(title: const Text('Clientes'), onTap: () => Navigator.pushNamed(context, '/customers/new')),
            ListTile(title: const Text('Vendas'), onTap: () => Navigator.pushNamed(context, '/sales/new')),
            ListTile(title: const Text('Histórico de Vendas'), onTap: () => Navigator.pushNamed(context, '/sales/history')),
            ListTile(title: const Text('Contas'), onTap: () => Navigator.pushNamed(context, '/accounts')),
            ListTile(title: const Text('Relatórios'), onTap: () => Navigator.pushNamed(context, '/reports')),
            ListTile(title: const Text('Configurações'), onTap: () => Navigator.pushNamed(context, '/settings')),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: _statCard('Produtos', totalProducts.toString())),
                const SizedBox(width: 12),
                Expanded(child: _statCard('Clientes', totalClients.toString())),
                const SizedBox(width: 12),
                Expanded(child: _statCard('Faturamento', 'R\$ ' + totalSales.toStringAsFixed(2))),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(child: _recentSales()),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String title, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(fontSize: 20)),
        ]),
      ),
    );
  }

  Widget _recentSales() {
    final sales = repo.sales;
    if (sales.isEmpty) {
      return const Center(child: Text('Nenhuma venda ainda'));
    }
    return ListView.builder(
      itemCount: sales.length,
      itemBuilder: (c, i) {
        final s = sales[i];
        return Card(
          child: ListTile(
            title: Text('Venda \${s.id} - R\$ \${s.total.toStringAsFixed(2)}'),
            subtitle: Text('Cliente: \${s.customerId}'),
            trailing: Text('\${s.date.day}/\${s.date.month}/\${s.date.year}'),
          ),
        );
      },
    );
  }
}