import 'package:flutter/material.dart';
import '../data/data_repository.dart';

class SalesHistoryScreen extends StatefulWidget {
  const SalesHistoryScreen({super.key});
  @override
  State<SalesHistoryScreen> createState() => _SalesHistoryScreenState();
}

class _SalesHistoryScreenState extends State<SalesHistoryScreen> {
  final repo = DataRepository.instance;
  @override
  Widget build(BuildContext context) {
    final sales = repo.sales;
    return Scaffold(
      appBar: AppBar(title: const Text('Histórico de Vendas')),
      body: ListView.builder(
        itemCount: sales.length,
        itemBuilder: (c, i) {
          final s = sales[i];
          return Card(
            child: ExpansionTile(
              title: Text('Venda \${s.id} - R\$ \${s.total.toStringAsFixed(2)}'),
              subtitle: Text('Cliente: \${s.customerId} • \${s.date.day}/\${s.date.month}/\${s.date.year}'),
              children: s.items.map((it) => ListTile(title: Text(it.productName), subtitle: Text('\${it.quantity} x R\$ \${it.unitPrice.toStringAsFixed(2)}'))).toList(),
            ),
          );
        },
      ),
    );
  }
}