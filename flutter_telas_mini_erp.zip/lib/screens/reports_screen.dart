import 'package:flutter/material.dart';
import '../data/data_repository.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final repo = DataRepository.instance;
    final totalSales = repo.sales.fold<double>(0, (p, s) => p + s.total);
    final totalProducts = repo.products.length;
    final lowStock = repo.products.where((p)=> p.stock <= 5).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Relatórios')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(children: [
          Card(child: ListTile(title: const Text('Faturamento total'), trailing: Text('R\$ \${totalSales.toStringAsFixed(2)}'))),
          Card(child: ListTile(title: const Text('Total produtos cadastrados'), trailing: Text('\$totalProducts'.replaceAll('\$','')))),
          Card(child: ListTile(title: const Text('Produtos com baixo estoque'), trailing: Text('\$lowStock'.replaceAll('\$','')))),
          const SizedBox(height: 12),
          const Text('Relatórios simples (simulados)'),
          const SizedBox(height: 8),
          Expanded(child: Center(child: Text('Aqui poderiam aparecer gráficos usando pacotes como fl_chart'))),
        ]),
      ),
    );
  }
}