import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  String email = '';
  String pass = '';

  void _login() {
    if (_form.currentState?.validate() ?? false) {
      Navigator.pushReplacementNamed(context, '/dashboard');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 24),
                    Text('Mini ERP', style: Theme.of(context).textTheme.displaySmall),
                    const SizedBox(height: 8),
                    const Text('Gerencie vendas, estoque e finanças de forma simples.'),
                    const SizedBox(height: 32),
                    Form(
                      key: _form,
                      child: Column(
                        children: [
                          TextFormField(
                            decoration: const InputDecoration(labelText: 'E-mail'),
                            validator: (v) => (v==null || v.isEmpty) ? 'Informe e-mail' : null,
                            onSaved: (v) => email = v ?? '',
                          ),
                          const SizedBox(height: 12),
                          TextFormField(
                            decoration: const InputDecoration(labelText: 'Senha'),
                            obscureText: true,
                            validator: (v) => (v==null || v.isEmpty) ? 'Informe senha' : null,
                            onSaved: (v) => pass = v ?? '',
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            height: 48,
                            child: ElevatedButton(onPressed: (){
                              _form.currentState?.save();
                              _login();
                            }, child: const Text('Entrar')),
                          ),
                          const SizedBox(height: 12),
                          TextButton(onPressed: (){
                            Navigator.pushNamed(context, '/products');
                          }, child: const Text('Entrar sem login (ir para produtos)')),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}