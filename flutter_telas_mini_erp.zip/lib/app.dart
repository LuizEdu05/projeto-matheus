import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/product_form.dart';
import 'screens/product_list.dart';
import 'screens/customer_form.dart';
import 'screens/sale_screen.dart';
import 'screens/sales_history.dart';
import 'screens/accounts_screen.dart';
import 'screens/reports_screen.dart';
import 'screens/settings_screen.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mini ERP',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (c) => const LoginScreen(),
        '/dashboard': (c) => const DashboardScreen(),
        '/products/new': (c) => const ProductFormScreen(),
        '/products': (c) => const ProductListScreen(),
        '/customers/new': (c) => const CustomerFormScreen(),
        '/sales/new': (c) => const SaleScreen(),
        '/sales/history': (c) => const SalesHistoryScreen(),
        '/accounts': (c) => const AccountsScreen(),
        '/reports': (c) => const ReportsScreen(),
        '/settings': (c) => const SettingsScreen(),
      },
    );
  }
}