import '../models/product.dart';
import '../models/customer.dart';
import '../models/sale.dart';
import '../models/account.dart';

class DataRepository {
  // Singleton
  DataRepository._internal();
  static final DataRepository instance = DataRepository._internal();

  final List<Product> products = [
    Product(id: 'p1', name: 'Camiseta', price: 29.90, stock: 10),
    Product(id: 'p2', name: 'Caneta', price: 2.50, stock: 100),
    Product(id: 'p3', name: 'Caderno', price: 12.00, stock: 50),
  ];

  final List<Customer> customers = [
    Customer(id: 'c1', name: 'Loja A', phone: '1199999-0001'),
    Customer(id: 'c2', name: 'Cliente B', phone: '1199999-0002'),
  ];

  final List<Sale> sales = [];

  final List<Account> accounts = [
    Account(id: 'a1', title: 'Aluguel', amount: 1200.0, dueDate: DateTime.now().add(Duration(days: 7)), received: false, type: AccountType.payable),
    Account(id: 'a2', title: 'Venda Loja A', amount: 450.0, dueDate: DateTime.now().subtract(Duration(days: 2)), received: true, type: AccountType.receivable),
  ];

  void addProduct(Product p) {
    products.insert(0, p);
  }

  void addCustomer(Customer c) {
    customers.insert(0, c);
  }

  void addSale(Sale s) {
    sales.insert(0, s);
    // reduce stock
    for (final item in s.items) {
      final prod = products.firstWhere((p) => p.id == item.productId, orElse: () => null);
      if (prod != null) {
        prod.stock -= item.quantity;
      }
    }
    // add account receivable
    accounts.insert(0, Account(id: 'acc\${accounts.length+1}', title: 'Venda #\${s.id}', amount: s.total, dueDate: DateTime.now(), received: false, type: AccountType.receivable));
  }

  void toggleAccountPaid(String id) {
    final a = accounts.firstWhere((x) => x.id == id);
    a.received = !a.received;
  }
}