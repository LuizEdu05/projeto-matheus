Mini ERP - Projeto de telas (Flutter)

Conteúdo:
- App Flutter com 10 telas funcionais (simuladas, sem backend).
- Dados mantidos em memória (DataRepository) durante a execução.
- Usuário pode cadastrar produtos e clientes, criar vendas, ver histórico, marcar contas pagas, etc.

Como rodar:
1. Instale Flutter SDK: https://flutter.dev
2. Copie este diretório para sua máquina local.
3. No terminal, execute:
   flutter pub get
   flutter run

Nome do arquivo de entrega: flutter_telas_mini_erp.zip

Observações:
- Projeto focado em UI + lógica simulada.
- Não usa pacotes externos; facilita rodar direto.