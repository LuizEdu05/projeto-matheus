import 'package:flutter/material.dart';

class AccountsScreen extends StatelessWidget {
  const AccountsScreen({super.key});

  final List<Map<String, String>> accounts = const [
    {'name': 'Fornecedor A', 'status': 'Pendente', 'amount': 'R\$ 100,00'},
    {'name': 'Cliente B', 'status': 'Pago', 'amount': 'R\$ 50,00'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Contas a Pagar/Receber')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: accounts.length,
        itemBuilder: (_, index) {
          return Card(
            child: ListTile(
              title: Text(accounts[index]['name']!),
              subtitle: Text('Status: ${accounts[index]['status']}'),
              trailing: Text(accounts[index]['amount']!),
            ),
          );
        },
      ),
    );
  }
}
