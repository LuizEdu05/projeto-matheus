import 'package:flutter/material.dart';
import 'product_register_screen.dart';
import 'stock_list_screen.dart';
import 'client_register_screen.dart';
import 'sale_screen.dart';
import 'sales_history_screen.dart';
import 'accounts_screen.dart';
import 'reports_screen.dart';
import 'settings_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  Widget _menuButton(BuildContext context, String title, Widget screen) {
    return Card(
      child: ListTile(
        title: Text(title),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Bem-vindo ao Mini ERP', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          _menuButton(context, 'Cadastro de Produto', const ProductRegisterScreen()),
          _menuButton(context, 'Lista de Estoque', const StockListScreen()),
          _menuButton(context, 'Cadastro de Cliente', const ClientRegisterScreen()),
          _menuButton(context, 'Nova Venda', const SaleScreen()),
          _menuButton(context, 'Histórico de Vendas', const SalesHistoryScreen()),
          _menuButton(context, 'Contas a Pagar/Receber', const AccountsScreen()),
          _menuButton(context, 'Relatórios', const ReportsScreen()),
          _menuButton(context, 'Configurações', const SettingsScreen()),
        ],
      ),
    );
  }
}
