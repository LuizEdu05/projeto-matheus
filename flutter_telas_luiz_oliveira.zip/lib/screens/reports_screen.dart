import 'package:flutter/material.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Relatórios')),
      body: Center(
        child: Container(
          height: 200,
          width: 300,
          color: Colors.blue[50],
          child: const Center(child: Text('Gráfico de Vendas')),
        ),
      ),
    );
  }
}
