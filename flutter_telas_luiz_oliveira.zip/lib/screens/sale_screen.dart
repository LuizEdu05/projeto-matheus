import 'package:flutter/material.dart';

class SaleScreen extends StatelessWidget {
  const SaleScreen({super.key});

  final List<Map<String, dynamic>> products = const [
    {'name': 'Caneta', 'price': 2.50},
    {'name': 'Caderno', 'price': 12.00},
    {'name': 'Lápis', 'price': 1.50},
  ];

  @override
  Widget build(BuildContext context) {
    double total = products.fold(0, (sum, item) => sum + item['price'] as double);

    return Scaffold(
      appBar: AppBar(title: const Text('Nova Venda')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: products.length,
                itemBuilder: (_, index) {
                  return Card(
                    child: ListTile(
                      title: Text(products[index]['name']),
                      trailing: Text('R\$ ${products[index]['price']}'),
                    ),
                  );
                },
              ),
            ),
            Text('Total: R\$ $total', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: () {}, child: const Text('Finalizar Venda')),
          ],
        ),
      ),
    );
  }
}
