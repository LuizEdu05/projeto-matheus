import 'package:flutter/material.dart';

class StockListScreen extends StatelessWidget {
  const StockListScreen({super.key});

  final List<Map<String, String>> products = const [
    {'name': 'Caneta', 'price': 'R\$ 2,50'},
    {'name': 'Caderno', 'price': 'R\$ 12,00'},
    {'name': 'Lápis', 'price': 'R\$ 1,50'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lista de Estoque')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: products.length,
        itemBuilder: (_, index) {
          return Card(
            child: ListTile(
              title: Text(products[index]['name']!),
              subtitle: Text(products[index]['price']!),
            ),
          );
        },
      ),
    );
  }
}
