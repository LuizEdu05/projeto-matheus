import 'package:flutter/material.dart';

class ClientRegisterScreen extends StatelessWidget {
  const ClientRegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro de Cliente')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(decoration: const InputDecoration(labelText: 'Nome do Cliente')),
            const SizedBox(height: 16),
            TextField(decoration: const InputDecoration(labelText: 'Telefone')),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: () {}, child: const Text('Salvar Cliente')),
          ],
        ),
      ),
    );
  }
}
