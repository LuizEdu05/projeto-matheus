import 'package:flutter/material.dart';

class SalesHistoryScreen extends StatelessWidget {
  const SalesHistoryScreen({super.key});

  final List<Map<String, String>> sales = const [
    {'client': 'João', 'total': 'R\$ 20,00'},
    {'client': 'Maria', 'total': 'R\$ 15,50'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Histórico de Vendas')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: sales.length,
        itemBuilder: (_, index) {
          return Card(
            child: ListTile(
              title: Text('Cliente: ${sales[index]['client']}'),
              subtitle: Text('Total: ${sales[index]['total']}'),
            ),
          );
        },
      ),
    );
  }
}
