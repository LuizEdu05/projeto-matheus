import 'package:flutter/material.dart';

class ProductRegisterScreen extends StatelessWidget {
  const ProductRegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro de Produto')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(decoration: const InputDecoration(labelText: 'Nome do Produto')),
            const SizedBox(height: 16),
            TextField(decoration: const InputDecoration(labelText: 'Preço')),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: () {}, child: const Text('Salvar Produto')),
          ],
        ),
      ),
    );
  }
}
